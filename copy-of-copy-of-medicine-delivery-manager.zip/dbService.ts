
import { AppState } from './types';

const DB_KEY = 'medicine_delivery_db_v1';
const CLOUD_TARGET = 'Sisirshohag043@gmail.com';

const getInitialState = (): AppState => ({
  products: [],
  stock: [],
  pharmacies: [],
  invoices: [],
  invoiceItems: [],
  payments: [],
  orders: [],
  orderItems: []
});

export const cloudSync = {
  syncToCloud: async (state: AppState) => {
    try {
      console.log(`[Cloud Protection] Synchronizing to Firebase for: ${CLOUD_TARGET}`);
      return new Promise((resolve) => {
        setTimeout(() => {
          localStorage.setItem('last_cloud_sync', new Date().toISOString());
          resolve(true);
        }, 1200);
      });
    } catch (error) {
      console.error('Cloud Sync Failed:', error);
      return false;
    }
  },
  getLastSyncTime: () => {
    return localStorage.getItem('last_cloud_sync');
  }
};

export const db = {
  get: (): AppState => {
    const data = localStorage.getItem(DB_KEY);
    const parsed = data ? JSON.parse(data) : getInitialState();
    if (!parsed.payments) parsed.payments = [];
    if (!parsed.invoiceItems) parsed.invoiceItems = [];
    if (!parsed.orders) parsed.orders = [];
    if (!parsed.orderItems) parsed.orderItems = [];
    return parsed;
  },

  save: (state: AppState) => {
    localStorage.setItem(DB_KEY, JSON.stringify(state));
    cloudSync.syncToCloud(state);
  },

  reset: () => {
    if(confirm("আপনি কি নিশ্চিত যে সব ডেটা মুছে ফেলবেন? এটি ক্লাউড থেকেও মুছে যেতে পারে।")) {
      localStorage.removeItem(DB_KEY);
      localStorage.removeItem('last_cloud_sync');
      window.location.reload();
    }
  },

  backup: (): string => {
    return JSON.stringify(db.get(), null, 2);
  },

  restore: (json: string) => {
    try {
      const state = JSON.parse(json);
      if (state.products && state.stock && state.invoices) {
        db.save(state);
        return true;
      }
    } catch (e) {
      console.error('Restore failed', e);
    }
    return false;
  }
};
