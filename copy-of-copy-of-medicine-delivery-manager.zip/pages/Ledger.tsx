
import React, { useState } from 'react';
import { AppState, Pharmacy, Invoice, Payment } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const LedgerPage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [selectedPharId, setSelectedPharId] = useState<string | null>(null);
  const [editingPaymentInv, setEditingPaymentInv] = useState<Invoice | null>(null);
  const [newCash, setNewCash] = useState(0);

  const pharInvoices = state.invoices.filter(inv => inv.pharmacy_id === selectedPharId);
  const totalDue = pharInvoices.reduce((sum, inv) => sum + inv.due_amount, 0);

  const handleUpdatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPaymentInv || newCash <= 0) return;

    const paymentRecord: Payment = {
      id: crypto.randomUUID(),
      invoice_id: editingPaymentInv.id,
      pharmacy_id: editingPaymentInv.pharmacy_id,
      amount: newCash,
      date: new Date().toISOString().split('T')[0],
      type: 'Due_Collection'
    };

    setState(prev => ({
      ...prev,
      invoices: prev.invoices.map(inv => {
        if (inv.id === editingPaymentInv.id) {
          const updatedCash = inv.cash_received + newCash;
          return {
            ...inv,
            cash_received: updatedCash,
            due_amount: Math.max(0, inv.total_amount - updatedCash),
            status: (inv.total_amount - updatedCash) <= 0 ? 'Paid' : 'Partial'
          };
        }
        return inv;
      }),
      payments: [...prev.payments, paymentRecord]
    }));
    setEditingPaymentInv(null);
    setNewCash(0);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-emerald-900">ফার্মেসি লেজার</h2>
      
      {!selectedPharId ? (
        <div className="space-y-3">
          {state.pharmacies.map(phar => {
            const due = state.invoices
              .filter(inv => inv.pharmacy_id === phar.id)
              .reduce((sum, inv) => sum + inv.due_amount, 0);
            
            return (
              <button 
                key={phar.id} 
                onClick={() => setSelectedPharId(phar.id)}
                className="w-full bg-white p-5 rounded-2xl border-2 border-emerald-50 shadow-sm flex justify-between items-center text-left active:scale-95 transition-all hover:border-emerald-200"
              >
                <div>
                  <h3 className="font-bold text-lg text-emerald-800">{phar.name}</h3>
                  <p className="text-xs text-gray-500">{phar.address || 'ঠিকানা নেই'}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">মোট বাকি</p>
                  <p className={`font-black text-xl ${due > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>৳{due}</p>
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="space-y-4">
          <button 
            onClick={() => setSelectedPharId(null)}
            className="text-emerald-600 font-black mb-2 flex items-center bg-emerald-50 px-4 py-2 rounded-xl"
          >
            ← ফিরে যান
          </button>
          
          <div className="bg-emerald-600 text-white p-6 rounded-3xl shadow-xl animate-in">
            <h3 className="text-2xl font-black mb-1">{state.pharmacies.find(p => p.id === selectedPharId)?.name}</h3>
            <p className="opacity-80 font-bold uppercase text-[10px] tracking-widest">বকেয়া পরিমাণ:</p>
            <p className="text-4xl font-black mt-2">৳{totalDue}</p>
          </div>

          <h4 className="font-bold text-lg border-b-2 border-emerald-50 pb-2 text-emerald-800">ইনভয়েস ইতিহাস</h4>
          <div className="space-y-3">
            {pharInvoices.length === 0 ? (
              <p className="text-center text-gray-500 py-6">কোন লেনদেন নেই।</p>
            ) : (
              pharInvoices.slice().reverse().map(inv => (
                <div key={inv.id} className="bg-white p-4 rounded-2xl border-2 border-emerald-50 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-black text-emerald-700">{inv.invoice_no}</p>
                      <p className="text-[10px] font-bold text-gray-400 uppercase">{inv.delivery_date}</p>
                    </div>
                    {inv.due_amount > 0 && (
                      <button 
                        onClick={() => setEditingPaymentInv(inv)}
                        className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-xl text-xs font-black shadow-sm"
                      >
                        টাকা জমা
                      </button>
                    )}
                  </div>
                  <div className="flex justify-between text-sm mt-3 border-t-2 border-emerald-50 pt-2 font-bold">
                    <p className="text-gray-500">বিল: ৳{inv.total_amount}</p>
                    <p className="text-emerald-600">জমা: ৳{inv.cash_received}</p>
                    <p className="text-rose-600">বাকি: ৳{inv.due_amount}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {editingPaymentInv && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <form onSubmit={handleUpdatePayment} className="bg-white p-8 rounded-3xl w-full max-w-sm shadow-2xl animate-in">
            <h2 className="text-2xl font-black mb-2 text-emerald-800">পেমেন্ট জমা</h2>
            <p className="text-xs text-gray-500 mb-6 font-bold uppercase tracking-wider">{editingPaymentInv.invoice_no} এর জন্য টাকা জমা নিন</p>
            <div className="space-y-5">
              <div>
                <p className="text-xs text-emerald-600 font-bold mb-2">বাকি আছে: ৳{editingPaymentInv.due_amount}</p>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 ml-1">জমার পরিমাণ (৳)</label>
                <input 
                  autoFocus
                  required
                  type="number" 
                  max={editingPaymentInv.due_amount}
                  value={newCash || ''} 
                  onChange={e => setNewCash(Number(e.target.value))}
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-2xl p-4 text-2xl font-black text-emerald-900 outline-none focus:ring-4 focus:ring-emerald-200 transition-all text-center"
                />
              </div>
              <div className="flex gap-4 pt-2">
                <button type="button" onClick={() => setEditingPaymentInv(null)} className="flex-1 font-bold text-gray-400 py-3">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-600 text-white p-4 rounded-2xl font-black shadow-xl active:scale-95">জমা করুন</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default LedgerPage;
