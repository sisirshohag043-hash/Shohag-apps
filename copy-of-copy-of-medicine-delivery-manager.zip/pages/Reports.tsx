
import React from 'react';
import { AppState } from '../types';

interface Props {
  state: AppState;
}

declare const jspdf: any;

const ReportsPage: React.FC<Props> = ({ state }) => {
  const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
  
  const monthlyInvoices = state.invoices.filter(inv => inv.delivery_date.startsWith(currentMonth));
  const monthlyTotal = monthlyInvoices.reduce((s, i) => s + i.total_amount, 0);
  const monthlyCash = state.payments
    .filter(p => p.date.startsWith(currentMonth))
    .reduce((s, p) => s + p.amount, 0);
  const monthlyDue = monthlyTotal - monthlyCash;

  const downloadReport = (title: string, data: any[], columns: string[]) => {
    const doc = new jspdf.jsPDF();
    doc.text(title, 14, 15);
    doc.autoTable({
      head: [columns],
      body: data,
      startY: 20,
    });
    doc.save(`${title.replace(/\s+/g, '_').toLowerCase()}.pdf`);
  };

  const exportMonthlyReport = () => {
    const data = monthlyInvoices.map(inv => [
      inv.invoice_no,
      state.pharmacies.find(p => p.id === inv.pharmacy_id)?.name || 'N/A',
      inv.delivery_date,
      inv.total_amount,
      inv.cash_received,
      inv.due_amount
    ]);
    downloadReport(`Monthly Sales Report - ${currentMonth}`, data, ['Invoice', 'Pharmacy', 'Date', 'Total', 'Paid', 'Due']);
  };

  const exportTransactionLog = () => {
    // Collect all dates from invoices and payments
    const allDates = Array.from(new Set([
      ...state.invoices.map(i => i.delivery_date),
      ...state.payments.map(p => p.date)
    ])).sort().reverse();

    const data: any[] = [];
    allDates.forEach(date => {
      state.pharmacies.forEach(phar => {
        const sales = state.invoices
          .filter(i => i.delivery_date === date && i.pharmacy_id === phar.id)
          .reduce((s, i) => s + i.total_amount, 0);
        
        const collected = state.payments
          .filter(p => p.date === date && p.pharmacy_id === phar.id)
          .reduce((s, p) => s + p.amount, 0);

        if (sales > 0 || collected > 0) {
          data.push([date, phar.name, sales, collected]);
        }
      });
    });

    downloadReport('Daily Transaction Log', data, ['Date', 'Pharmacy', 'Sales Amount', 'Collected Amount']);
  };

  const exportDueReport = () => {
    const data = state.pharmacies.map(phar => {
      const due = state.invoices
        .filter(inv => inv.pharmacy_id === phar.id)
        .reduce((sum, inv) => sum + inv.due_amount, 0);
      return [phar.name, phar.mobile, due];
    }).filter(row => (row[2] as number) > 0);
    downloadReport('Pharmacy Due Report', data, ['Pharmacy', 'Mobile', 'Total Due']);
  };

  return (
    <div className="space-y-6 pb-12">
      <h2 className="text-2xl font-bold text-emerald-900">রিপোর্ট ও লেনদেন ইতিহাস</h2>
      
      <div className="bg-white p-6 rounded-3xl shadow-sm border-2 border-emerald-50">
        <h3 className="font-black text-lg mb-4 text-emerald-800 uppercase tracking-tighter">এই মাসের সামারি ({currentMonth})</h3>
        <div className="grid grid-cols-1 gap-4">
          <div className="flex justify-between border-b-2 border-emerald-50 pb-2">
            <span className="text-gray-500 font-bold">মোট বিক্রি:</span>
            <span className="font-black text-xl text-gray-800">৳{monthlyTotal}</span>
          </div>
          <div className="flex justify-between border-b-2 border-emerald-50 pb-2">
            <span className="text-gray-500 font-bold">মোট আদায়:</span>
            <span className="font-black text-xl text-emerald-600">৳{monthlyCash}</span>
          </div>
          <div className="flex justify-between border-b-2 border-emerald-50 pb-2">
            <span className="text-gray-500 font-bold">মোট বাকি:</span>
            <span className="font-black text-xl text-rose-600">৳{monthlyTotal - monthlyCash}</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-emerald-800 ml-1">রিপোর্ট ডাউনলোড করুন</h3>
        <div className="grid grid-cols-1 gap-3">
          <ReportButton 
            title="দৈনিক লেনদেন রিপোর্ট" 
            desc="কোন তারিখে কোন ফার্মেসী কত সেল ও কালেকশন করেছে" 
            icon="📅" 
            onClick={exportTransactionLog} 
            color="bg-emerald-600"
          />
          <ReportButton 
            title="বকেয়া/ডিউ রিপোর্ট" 
            desc="ফার্মেসি অনুযায়ী মোট বাকি টাকার লিস্ট" 
            icon="💳" 
            onClick={exportDueReport} 
            color="bg-rose-600"
          />
          <ReportButton 
            title="মাসিক সেলস রিপোর্ট" 
            desc="ইনভয়েস অনুযায়ী বিস্তারিত সেলস" 
            icon="📊" 
            onClick={exportMonthlyReport} 
            color="bg-emerald-500"
          />
        </div>
      </div>

      <div className="bg-emerald-50 p-6 rounded-3xl border-2 border-emerald-100 text-center">
        <p className="text-sm text-emerald-700 font-bold">সমস্ত রিপোর্ট অটোমেটিক PDF ফরম্যাটে সেভ হবে।</p>
      </div>
    </div>
  );
};

const ReportButton = ({ title, desc, icon, onClick, color }: { title: string, desc: string, icon: string, onClick: () => void, color: string }) => (
  <button 
    onClick={onClick}
    className="bg-white p-5 rounded-3xl border-2 border-emerald-50 shadow-sm flex items-center gap-5 text-left active:scale-95 transition-all hover:border-emerald-300 group"
  >
    <div className={`w-14 h-14 ${color} text-white rounded-2xl flex items-center justify-center text-3xl shadow-lg group-hover:rotate-6 transition-transform`}>
      {icon}
    </div>
    <div className="flex-1">
      <h4 className="font-black text-lg leading-tight text-gray-800">{title}</h4>
      <p className="text-xs text-gray-400 font-bold mt-1 uppercase tracking-tight">{desc}</p>
    </div>
    <span className="text-emerald-200 text-2xl">→</span>
  </button>
);

export default ReportsPage;
