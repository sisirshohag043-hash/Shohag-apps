
import React, { useEffect, useState } from 'react';
import { AppState } from '../types';
import { cloudSync } from '../dbService';

interface Props {
  state: AppState;
  setActiveTab: (tab: string) => void;
}

const Dashboard: React.FC<Props> = ({ state, setActiveTab }) => {
  const [lastSync, setLastSync] = useState<string | null>(null);
  
  useEffect(() => {
    setLastSync(cloudSync.getLastSyncTime());
    const interval = setInterval(() => {
      setLastSync(cloudSync.getLastSyncTime());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const today = new Date().toISOString().split('T')[0];
  const totalSales = state.invoices.reduce((sum, inv) => sum + inv.total_amount, 0);
  const totalDue = state.invoices.reduce((sum, inv) => sum + inv.due_amount, 0);
  
  const todayInvoices = state.invoices.filter(inv => inv.delivery_date === today);
  const todayCollection = todayInvoices.reduce((sum, inv) => sum + inv.cash_received, 0);

  const pendingOrdersCount = state.orders.filter(o => o.status === 'Pending').length;
  const lowStockItems = state.stock.filter(s => s.quantity <= (s.min_limit || 5));

  return (
    <div className="space-y-6 pb-12 animate-in">
      {/* Premium Security Header */}
      <div className="app-gradient p-6 rounded-[2.5rem] shadow-2xl flex items-center justify-between border-b-4 border-emerald-900/50">
        <div className="flex items-center gap-4">
          <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-md border border-white/20 shadow-inner">
            <span className="text-3xl">🛡️</span>
          </div>
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-100/60">Cloud Protection</h4>
            <p className="text-white font-bold text-lg leading-tight">আপনার সব ডেটা নিরাপদ</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[9px] font-black text-emerald-200/50 uppercase">Update</p>
          <p className="text-[11px] font-mono text-white font-bold">{lastSync ? new Date(lastSync).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Syncing...'}</p>
        </div>
      </div>

      {/* Modern Grid Stats */}
      <div className="grid grid-cols-2 gap-4">
        <StatCard title="আজকের জমা" value={`৳${todayCollection}`} color="bg-emerald-600 shadow-emerald-200" icon="💰" />
        <StatCard title="পেন্ডিং অর্ডার" value={pendingOrdersCount} color="bg-amber-500 shadow-amber-200" icon="🛒" />
        <StatCard title="মোট বকেয়া" value={`৳${totalDue}`} color="bg-rose-600 shadow-rose-200" icon="💳" />
        <StatCard title="মোট সেলস" value={`৳${totalSales}`} color="bg-sky-700 shadow-sky-200" icon="📊" />
      </div>

      {/* Action Shortcuts */}
      <div className="grid grid-cols-3 gap-3">
        <ActionBtn onClick={() => setActiveTab('products')} icon="📦" label="নতুন মাল" />
        <ActionBtn onClick={() => setActiveTab('orders')} icon="🛒" label="অর্ডার নিন" />
        <ActionBtn onClick={() => setActiveTab('invoices')} icon="📝" label="নতুন বিল" />
      </div>

      {/* Low Stock Notification */}
      {lowStockItems.length > 0 && (
        <div className="bg-white border-l-8 border-rose-500 p-5 rounded-[2rem] shadow-xl shadow-rose-100/50 flex flex-col gap-2">
          <div className="flex items-center gap-2 text-rose-600 font-black uppercase text-xs">
            <span className="animate-pulse">⚠️</span> স্টক শেষ হচ্ছে!
          </div>
          <div className="space-y-1">
            {lowStockItems.slice(0, 2).map(s => (
              <div key={s.id} className="flex justify-between items-center bg-rose-50 px-4 py-2 rounded-xl">
                <p className="text-xs font-bold text-gray-700">{state.products.find(p => p.id === s.product_id)?.name}</p>
                <p className="text-xs font-black text-rose-600">{s.quantity} পিস</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transaction Feed */}
      <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-emerald-100/20 border border-emerald-50 overflow-hidden">
        <div className="p-6 bg-emerald-50/50 border-b border-emerald-100 flex justify-between items-center">
          <h2 className="text-sm font-black text-emerald-900 uppercase tracking-widest">সাম্প্রতিক লেনদেন</h2>
          <span className="text-[10px] font-black text-emerald-400">সর্বশেষ ৫টি</span>
        </div>
        <div className="divide-y divide-emerald-50">
          {state.invoices.length === 0 ? (
            <div className="p-10 text-center opacity-20">📥 কোনো ডেটা নেই</div>
          ) : (
            state.invoices.slice(-5).reverse().map(inv => {
              const phar = state.pharmacies.find(p => p.id === inv.pharmacy_id);
              return (
                <div key={inv.id} className="p-5 flex justify-between items-center active:bg-emerald-50/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-11 h-11 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center font-black text-lg border border-emerald-200">
                      {phar?.name[0] || 'U'}
                    </div>
                    <div>
                      <p className="font-black text-gray-800 leading-tight">{phar?.name || 'অজ্ঞাত'}</p>
                      <p className="text-[9px] text-gray-400 font-bold mt-1 uppercase">{inv.delivery_date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-emerald-800 text-lg leading-none">৳{inv.total_amount}</p>
                    <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full mt-1.5 inline-block ${inv.due_amount > 0 ? 'bg-rose-100 text-rose-500' : 'bg-emerald-100 text-emerald-600'}`}>
                      {inv.due_amount > 0 ? 'বাকি' : 'পেইড'}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, color, icon }: { title: string, value: string | number, color: string, icon: string }) => (
  <div className={`${color} p-5 rounded-[2.2rem] shadow-xl text-white relative overflow-hidden active:scale-95 transition-all`}>
    <span className="absolute -right-2 -bottom-2 text-5xl opacity-10">{icon}</span>
    <p className="text-[10px] font-black uppercase tracking-widest opacity-60 leading-tight">{title}</p>
    <p className="text-2xl font-black mt-2 drop-shadow-sm">{value}</p>
  </div>
);

const ActionBtn = ({ onClick, icon, label }: { onClick: () => void, icon: string, label: string }) => (
  <button onClick={onClick} className="bg-white border-2 border-emerald-50 p-4 rounded-[1.8rem] shadow-lg flex flex-col items-center gap-2 active:scale-90 transition-all hover:border-emerald-500 group">
    <span className="text-2xl group-hover:scale-125 transition-transform">{icon}</span>
    <span className="text-[9px] font-black text-emerald-800 uppercase tracking-tighter">{label}</span>
  </button>
);

export default Dashboard;
