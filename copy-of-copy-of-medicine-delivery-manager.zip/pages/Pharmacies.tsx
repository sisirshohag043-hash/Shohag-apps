
import React, { useState } from 'react';
import { AppState, Pharmacy } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const PharmacyPage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [editing, setEditing] = useState<Partial<Pharmacy> | null>(null);
  const [search, setSearch] = useState('');

  const filtered = state.pharmacies.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.mobile.includes(search)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.name) return;

    if (editing.id) {
      setState(prev => ({
        ...prev,
        pharmacies: prev.pharmacies.map(p => p.id === editing.id ? (editing as Pharmacy) : p)
      }));
    } else {
      const newPharmacy: Pharmacy = {
        id: Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
        name: editing.name,
        address: editing.address || '',
        mobile: editing.mobile || ''
      };
      setState(prev => ({
        ...prev,
        pharmacies: [...prev.pharmacies, newPharmacy]
      }));
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('এই ফার্মেসি ডিলিট করতে চান?')) {
      requireAdmin(() => {
        setState(prev => ({
          ...prev,
          pharmacies: prev.pharmacies.filter(p => p.id !== id),
          invoices: prev.invoices.filter(i => i.pharmacy_id !== id)
        }));
      });
    }
  };

  return (
    <div className="space-y-4 animate-in">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-black text-emerald-900 uppercase tracking-tighter">দোকান লিস্ট</h2>
        <button 
          onClick={() => setEditing({})}
          className="bg-emerald-700 text-white px-5 py-3 rounded-2xl font-black shadow-xl shadow-emerald-200 active:scale-95 transition-all text-xs uppercase"
        >
          ➕ নতুন দোকান
        </button>
      </div>

      <div className="relative">
        <input 
          type="text"
          placeholder="দোকানের নাম বা মোবাইল দিয়ে খুঁজুন..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-white border-2 border-emerald-100 rounded-[1.5rem] p-4 pl-12 font-bold text-emerald-900 outline-none shadow-sm focus:border-emerald-500 transition-all"
        />
        <span className="absolute left-4 top-1/2 -translate-y-1/2 opacity-30 text-xl">🔍</span>
      </div>

      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-[2.5rem] border-4 border-dashed border-emerald-50">
            <span className="text-6xl block mb-4 opacity-10">🏥</span>
            <p className="text-[10px] font-black text-emerald-800/30 uppercase tracking-[0.4em]">কোনো দোকান পাওয়া যায়নি</p>
          </div>
        ) : (
          filtered.map(p => (
            <div key={p.id} className="bg-white p-6 rounded-[2rem] border-2 border-emerald-50 shadow-xl shadow-emerald-100/20 group hover:border-emerald-300 transition-all">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-black text-xl text-emerald-900 leading-tight">{p.name}</h3>
                  <div className="mt-3 space-y-2">
                    <p className="text-xs text-gray-500 flex items-center gap-2">
                      <span className="w-6 h-6 bg-emerald-50 rounded-lg flex items-center justify-center text-[10px]">📍</span> 
                      {p.address || <span className="italic opacity-50">ঠিকানা নেই</span>}
                    </p>
                    <p className="text-xs text-emerald-600 font-black flex items-center gap-2">
                      <span className="w-6 h-6 bg-emerald-50 rounded-lg flex items-center justify-center text-[10px]">📞</span> 
                      {p.mobile || <span className="italic opacity-50 font-normal text-gray-400">মোবাইল নেই</span>}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditing(p)} className="bg-emerald-50 text-emerald-600 p-3 rounded-2xl hover:bg-emerald-600 hover:text-white transition-all active:scale-90">✏️</button>
                  <button onClick={() => handleDelete(p.id)} className="bg-rose-50 text-rose-300 p-3 rounded-2xl hover:bg-rose-500 hover:text-white transition-all active:scale-90">🗑️</button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 bg-emerald-900/60 backdrop-blur-xl z-[100] p-4 flex items-center justify-center">
          <form onSubmit={handleSubmit} className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl p-8 border-4 border-white animate-in">
            <h2 className="text-2xl font-black mb-6 text-emerald-800 uppercase tracking-tighter">{editing.id ? 'দোকান এডিট' : 'নতুন দোকান'}</h2>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">দোকানের নাম *</label>
                <input 
                  autoFocus
                  required
                  type="text" 
                  value={editing.name || ''} 
                  onChange={e => setEditing({...editing, name: e.target.value})}
                  className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none focus:ring-4 focus:ring-emerald-200"
                  placeholder="নাম লিখুন"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">ঠিকানা</label>
                <input 
                  type="text" 
                  value={editing.address || ''} 
                  onChange={e => setEditing({...editing, address: e.target.value})}
                  className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none"
                  placeholder="ঠিকানা"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">মোবাইল নম্বর</label>
                <input 
                  type="text" 
                  value={editing.mobile || ''} 
                  onChange={e => setEditing({...editing, mobile: e.target.value})}
                  className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none"
                  placeholder="017xxxxxxxx"
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setEditing(null)} className="flex-1 font-black text-gray-400 uppercase text-xs">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-700 text-white py-5 rounded-2xl font-black shadow-xl active:scale-95 transition-all uppercase text-xs">সেভ করুন</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default PharmacyPage;
