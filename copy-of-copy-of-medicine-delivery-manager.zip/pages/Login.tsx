
import React, { useState } from 'react';

interface Props {
  onLoginSuccess: () => void;
}

const LoginPage: React.FC<Props> = ({ onLoginSuccess }) => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Using the same credentials provided for Shishir
    if (userId === '01818813357' && password === '01818813357') {
      onLoginSuccess();
    } else {
      setError('ভুল আইডি অথবা পাসওয়ার্ড! আবার চেষ্টা করুন।');
    }
  };

  return (
    <div className="min-h-screen bg-emerald-50 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="w-24 h-24 bg-emerald-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl rotate-3 mb-6">
            <span className="text-5xl text-white">🚚</span>
          </div>
          <h1 className="text-3xl font-black text-emerald-900 leading-tight">শিশির ডেলিভারি <br/>ম্যানেজমেন্ট</h1>
          <p className="text-emerald-600 font-bold text-xs uppercase tracking-[0.3em] mt-2">Product Delivery Panel</p>
        </div>

        <form onSubmit={handleLogin} className="bg-white p-8 rounded-[2.5rem] shadow-2xl border-4 border-white space-y-6">
          <div>
            <label className="block text-[10px] font-black text-emerald-700 uppercase mb-2 ml-1">ইউজার আইডি</label>
            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              className="w-full border-2 border-emerald-500 rounded-2xl p-4 bg-emerald-100 text-emerald-900 font-black focus:ring-4 focus:ring-emerald-200 outline-none transition-all placeholder-emerald-300"
              placeholder="আইডি নম্বর লিখুন"
              required
            />
          </div>

          <div>
            <label className="block text-[10px] font-black text-emerald-700 uppercase mb-2 ml-1">পাসওয়ার্ড</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border-2 border-emerald-500 rounded-2xl p-4 bg-emerald-100 text-emerald-900 font-black focus:ring-4 focus:ring-emerald-200 outline-none transition-all placeholder-emerald-300"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="bg-rose-50 text-rose-600 p-3 rounded-xl text-xs text-center font-bold border-2 border-rose-100 animate-bounce">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-emerald-600 text-white p-5 rounded-2xl font-black text-xl shadow-xl shadow-emerald-200 active:scale-95 transition-all transform hover:-translate-y-1"
          >
            লগইন করুন
          </button>
        </form>

        <div className="mt-12 text-center space-y-2">
          <p className="text-[10px] text-emerald-800/40 font-black uppercase tracking-widest">Powered By</p>
          <p className="text-sm text-emerald-900 font-black">Shohag Vai | 01302420275</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
