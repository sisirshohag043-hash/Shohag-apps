
import React, { useState } from 'react';
import { AppState, Invoice, InvoiceItem, Payment } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const InvoicePage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [invoiceNo, setInvoiceNo] = useState('');
  const [pharmacyId, setPharmacyId] = useState('');
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [items, setItems] = useState<{ productId: string, qty: number }[]>([]);
  const [cashReceived, setCashReceived] = useState(0);

  const calculateTotal = () => {
    return items.reduce((sum, item) => {
      const product = state.products.find(p => p.id === item.productId);
      return sum + (product ? product.price * item.qty : 0);
    }, 0);
  };

  const addItem = () => setItems([...items, { productId: '', qty: 1 }]);
  const removeItem = (index: number) => setItems(items.filter((_, i) => i !== index));
  const updateItem = (index: number, key: 'productId' | 'qty', val: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [key]: val };
    setItems(newItems);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pharmacyId || items.length === 0) return;

    const totalAmount = calculateTotal();
    const invId = generateId();
    const dueAmount = totalAmount - cashReceived;

    const newInvoice: Invoice = {
      id: invId,
      invoice_no: invoiceNo || `INV-${Date.now().toString().slice(-6)}`,
      pharmacy_id: pharmacyId,
      delivery_date: deliveryDate,
      total_amount: totalAmount,
      cash_received: cashReceived,
      due_amount: dueAmount,
      status: dueAmount <= 0 ? 'Paid' : (cashReceived > 0 ? 'Partial' : 'Due')
    };

    const newInvoiceItems: InvoiceItem[] = items.map(item => {
      const p = state.products.find(prod => prod.id === item.productId)!;
      return {
        id: generateId(),
        invoice_id: invId,
        product_id: item.productId,
        quantity: item.qty,
        unit_price: p.price,
        subtotal: p.price * item.qty
      };
    });

    const initialPayment: Payment | null = cashReceived > 0 ? {
      id: generateId(),
      invoice_id: invId,
      pharmacy_id: pharmacyId,
      amount: cashReceived,
      date: deliveryDate,
      type: 'Sale'
    } : null;

    setState(prev => {
      const updatedStock = [...prev.stock];
      newInvoiceItems.forEach(item => {
        const stockIdx = updatedStock.findIndex(s => s.product_id === item.product_id);
        if (stockIdx !== -1) {
          updatedStock[stockIdx] = {
            ...updatedStock[stockIdx],
            quantity: Math.max(0, updatedStock[stockIdx].quantity - item.quantity)
          };
        }
      });

      return {
        ...prev,
        invoices: [...prev.invoices, newInvoice],
        invoiceItems: [...prev.invoiceItems, ...newInvoiceItems],
        stock: updatedStock,
        payments: initialPayment ? [...prev.payments, initialPayment] : prev.payments
      };
    });

    setIsCreating(false);
    resetForm();
  };

  const resetForm = () => {
    setInvoiceNo('');
    setPharmacyId('');
    setItems([]);
    setCashReceived(0);
  };

  const handleDelete = (id: string) => {
    if (confirm('এই ইনভয়েস ডিলিট করতে চান?')) {
      requireAdmin(() => {
        setState(prev => ({
          ...prev,
          invoices: prev.invoices.filter(i => i.id !== id),
          invoiceItems: prev.invoiceItems.filter(ii => ii.invoice_id !== id),
          payments: prev.payments.filter(p => p.invoice_id !== id)
        }));
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-black text-emerald-900 uppercase tracking-tighter">বিল লিস্ট</h2>
        <button 
          onClick={() => setIsCreating(true)}
          className="bg-emerald-700 text-white px-5 py-2.5 rounded-2xl font-black shadow-lg shadow-emerald-100 active:scale-95 transition-all text-xs uppercase"
        >
          ➕ নতুন বিল
        </button>
      </div>

      {isCreating ? (
        <div className="fixed inset-0 bg-emerald-900/40 backdrop-blur-xl z-[100] p-4 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl p-8 border-4 border-white animate-in">
            <h2 className="text-2xl font-black mb-6 text-emerald-800 uppercase tracking-tighter">নতুন বিল এন্ট্রি</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input type="text" value={invoiceNo} onChange={e => setInvoiceNo(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none" placeholder="বিল নং" />
                <input type="date" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none" />
              </div>
              <select required value={pharmacyId} onChange={e => setPharmacyId(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none">
                <option value="">দোকান সিলেক্ট করুন...</option>
                {state.pharmacies.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>

              <div className="bg-emerald-800 text-white p-6 rounded-[2rem] space-y-3 shadow-inner">
                <div className="flex justify-between items-center border-b border-white/10 pb-2">
                  <span className="text-[10px] font-black uppercase opacity-60">মোট বিল</span>
                  <span className="text-2xl font-black">৳{calculateTotal()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase opacity-60">নগদ গ্রহণ</span>
                  <input type="number" value={cashReceived} onChange={e => setCashReceived(Number(e.target.value))} className="w-24 bg-white/10 border border-white/20 rounded-xl p-2 text-right font-black outline-none" />
                </div>
                <div className="flex justify-between items-center border-t border-white/10 pt-2 text-amber-300">
                  <span className="text-[10px] font-black uppercase">বাকি</span>
                  <span className="text-xl font-black">৳{calculateTotal() - cashReceived}</span>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => { setIsCreating(false); resetForm(); }} className="flex-1 font-black text-gray-400 uppercase text-xs">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-700 text-white py-4 rounded-2xl font-black shadow-lg shadow-emerald-100 active:scale-95 transition-all uppercase text-xs">বিল সেভ</button>
              </div>
            </form>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {state.invoices.length === 0 ? (
            <div className="text-center py-24 bg-white rounded-[2.5rem] border-2 border-dashed border-emerald-100">
              <span className="text-5xl block mb-3 opacity-20">📄</span>
              <p className="text-xs font-black text-emerald-800/30 uppercase tracking-widest">এখনো কোনো বিল নেই</p>
            </div>
          ) : (
            state.invoices.slice().reverse().map(inv => {
              const phar = state.pharmacies.find(p => p.id === inv.pharmacy_id);
              return (
                <div key={inv.id} className="bg-white p-5 rounded-[2rem] border-2 border-emerald-50 shadow-sm hover:shadow-xl transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[8px] bg-emerald-100 px-2 py-0.5 rounded-full text-emerald-700 font-black uppercase">{inv.invoice_no}</span>
                      <h3 className="font-black text-lg mt-1 text-emerald-900 leading-none">{phar?.name || 'অজ্ঞাত'}</h3>
                      <p className="text-[9px] text-gray-400 font-bold mt-1 uppercase">{inv.delivery_date}</p>
                    </div>
                    <button onClick={() => handleDelete(inv.id)} className="text-rose-200 p-2 hover:text-rose-500 transition-all active:scale-75">🗑️</button>
                  </div>
                  <div className="grid grid-cols-3 gap-3 mt-5">
                    <div className="bg-gray-50 p-3 rounded-2xl text-center">
                      <p className="text-[7px] font-black text-gray-400 uppercase leading-none mb-1">মোট</p>
                      <p className="font-black text-gray-700 text-sm">৳{inv.total_amount}</p>
                    </div>
                    <div className="bg-emerald-50 p-3 rounded-2xl text-center">
                      <p className="text-[7px] font-black text-emerald-400 uppercase leading-none mb-1">আদায়</p>
                      <p className="font-black text-emerald-700 text-sm">৳{inv.cash_received}</p>
                    </div>
                    <div className="bg-rose-50 p-3 rounded-2xl text-center">
                      <p className="text-[7px] font-black text-rose-400 uppercase leading-none mb-1">বাকি</p>
                      <p className="font-black text-rose-700 text-sm">৳{inv.due_amount}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};

export default InvoicePage;
