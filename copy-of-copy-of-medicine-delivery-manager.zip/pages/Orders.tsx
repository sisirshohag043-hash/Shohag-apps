
import React, { useState } from 'react';
import { AppState, Order, OrderItem, Invoice, InvoiceItem } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const OrderPage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [orderNo, setOrderNo] = useState('');
  const [pharmacyId, setPharmacyId] = useState('');
  const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
  const [items, setItems] = useState<{ productId: string, qty: number }[]>([]);

  const calculateTotal = () => {
    return items.reduce((sum, item) => {
      const product = state.products.find(p => p.id === item.productId);
      return sum + (product ? product.price * item.qty : 0);
    }, 0);
  };

  const addItem = () => setItems([...items, { productId: '', qty: 1 }]);
  const removeItem = (index: number) => setItems(items.filter((_, i) => i !== index));
  const updateItem = (index: number, key: 'productId' | 'qty', val: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [key]: val };
    setItems(newItems);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pharmacyId || items.length === 0) return;

    const totalAmount = calculateTotal();
    const orderId = generateId();

    const newOrder: Order = {
      id: orderId,
      order_no: orderNo || `ORD-${Date.now().toString().slice(-6)}`,
      pharmacy_id: pharmacyId,
      order_date: orderDate,
      delivery_date: '',
      total_amount: totalAmount,
      status: 'Pending'
    };

    const newOrderItems: OrderItem[] = items.map(item => {
      const p = state.products.find(prod => prod.id === item.productId)!;
      return {
        id: generateId(),
        order_id: orderId,
        product_id: item.productId,
        quantity: item.qty,
        unit_price: p.price
      };
    });

    setState(prev => ({
      ...prev,
      orders: [...prev.orders, newOrder],
      orderItems: [...prev.orderItems, ...newOrderItems]
    }));

    setIsCreating(false);
    resetForm();
  };

  const resetForm = () => {
    setOrderNo('');
    setPharmacyId('');
    setItems([]);
  };

  const deliverOrder = (order: Order) => {
    if (!confirm('এই অর্ডারটি কি এখনই ডেলিভারি দিয়ে বিলে রূপান্তর করবেন?')) return;

    // 1. Get current order items reliably
    const currentOrderItems = state.orderItems.filter(oi => oi.order_id === order.id);
    if (currentOrderItems.length === 0) {
      alert('অর্ডারে কোনো মাল নেই!');
      return;
    }

    const invId = generateId();
    const invNo = `INV-${order.order_no.split('-')[1] || Date.now().toString().slice(-4)}`;

    // 2. Prepare Invoice and Invoice Items
    const newInvoice: Invoice = {
      id: invId,
      invoice_no: invNo,
      pharmacy_id: order.pharmacy_id,
      delivery_date: new Date().toISOString().split('T')[0],
      total_amount: order.total_amount,
      cash_received: 0,
      due_amount: order.total_amount,
      status: 'Due'
    };

    const newInvoiceItems: InvoiceItem[] = currentOrderItems.map(oi => ({
      id: generateId(),
      invoice_id: invId,
      product_id: oi.product_id,
      quantity: oi.quantity,
      unit_price: oi.unit_price,
      subtotal: oi.unit_price * oi.quantity
    }));

    // 3. Atomic State Update
    setState(prev => {
      const updatedStock = [...prev.stock];
      newInvoiceItems.forEach(item => {
        const stockIdx = updatedStock.findIndex(s => s.product_id === item.product_id);
        if (stockIdx !== -1) {
          updatedStock[stockIdx] = {
            ...updatedStock[stockIdx],
            quantity: Math.max(0, updatedStock[stockIdx].quantity - item.quantity)
          };
        }
      });

      return {
        ...prev,
        invoices: [...prev.invoices, newInvoice],
        invoiceItems: [...prev.invoiceItems, ...newInvoiceItems],
        stock: updatedStock,
        orders: prev.orders.map(o => o.id === order.id ? { ...o, status: 'Delivered' } : o)
      };
    });
    
    alert('সফলভাবে ডেলিভারি হয়েছে এবং ইনভয়েস তৈরি হয়েছে!');
  };

  const handleDelete = (id: string) => {
    if (confirm('অর্ডারটি ডিলিট করতে চান?')) {
      requireAdmin(() => {
        setState(prev => ({
          ...prev,
          orders: prev.orders.filter(o => o.id !== id),
          orderItems: prev.orderItems.filter(oi => oi.order_id !== id)
        }));
      });
    }
  };

  return (
    <div className="space-y-4 animate-in">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-black text-emerald-900 uppercase tracking-tighter">এডভান্স অর্ডার</h2>
        <button onClick={() => setIsCreating(true)} className="bg-emerald-700 text-white px-5 py-3 rounded-2xl font-black shadow-xl shadow-emerald-200 active:scale-95 transition-all text-xs uppercase">➕ নতুন অর্ডার</button>
      </div>

      {isCreating ? (
        <div className="fixed inset-0 bg-emerald-900/60 backdrop-blur-xl z-[100] p-4 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl p-8 border-4 border-white animate-in">
            <h2 className="text-2xl font-black mb-6 text-emerald-800 uppercase tracking-tighter">অর্ডার ফরম</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">নং</label>
                  <input type="text" value={orderNo} onChange={e => setOrderNo(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none focus:ring-4 focus:ring-emerald-200" placeholder="অটো" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">তারিখ</label>
                  <input type="date" value={orderDate} onChange={e => setOrderDate(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none focus:ring-4 focus:ring-emerald-200" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-emerald-600 uppercase ml-1">ফার্মেসি</label>
                <select required value={pharmacyId} onChange={e => setPharmacyId(e.target.value)} className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-4 font-black text-emerald-900 outline-none focus:ring-4 focus:ring-emerald-200">
                  <option value="">দোকান সিলেক্ট করুন...</option>
                  {state.pharmacies.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center"><h3 className="font-black text-xs uppercase text-emerald-800/40">মালের তালিকা</h3><button type="button" onClick={addItem} className="text-[10px] bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full font-black uppercase shadow-sm">➕ মাল যোগ</button></div>
                <div className="max-h-48 overflow-y-auto space-y-2 scrollbar-hide pr-1">
                  {items.map((item, idx) => (
                    <div key={idx} className="flex gap-2 bg-gray-50 p-4 rounded-2xl border-2 border-emerald-50 items-center shadow-sm">
                      <select required value={item.productId} onChange={e => updateItem(idx, 'productId', e.target.value)} className="flex-1 bg-white border border-emerald-200 rounded-xl p-2.5 text-xs font-black outline-none">
                        <option value="">সিলেক্ট...</option>
                        {state.products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                      <input type="number" min="1" value={item.qty} onChange={e => updateItem(idx, 'qty', Number(e.target.value))} className="w-16 bg-white border border-emerald-200 rounded-xl p-2.5 text-center font-black outline-none" />
                      <button type="button" onClick={() => removeItem(idx)} className="text-rose-400 px-2 font-black text-lg active:scale-75 transition-transform">✕</button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-emerald-800 text-white p-6 rounded-[2rem] flex justify-between items-center shadow-inner border-b-4 border-emerald-900">
                <span className="text-xs font-black uppercase opacity-60">মোট বিল:</span>
                <span className="text-2xl font-black">৳{calculateTotal()}</span>
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => { setIsCreating(false); resetForm(); }} className="flex-1 font-black text-gray-400 uppercase text-xs tracking-widest">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-700 text-white py-5 rounded-2xl font-black shadow-xl shadow-emerald-200 active:scale-95 transition-all uppercase text-xs">অর্ডার সেভ</button>
              </div>
            </form>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {state.orders.length === 0 ? (
            <div className="text-center py-32 bg-white rounded-[2.5rem] border-4 border-dashed border-emerald-50 shadow-inner">
              <span className="text-6xl block mb-4 opacity-10">🛒</span>
              <p className="text-[10px] font-black text-emerald-800/30 uppercase tracking-[0.4em]">অর্ডার লিস্ট খালি</p>
            </div>
          ) : (
            state.orders.slice().reverse().map(order => {
              const phar = state.pharmacies.find(p => p.id === order.pharmacy_id);
              const isDelivered = order.status === 'Delivered';
              return (
                <div key={order.id} className={`bg-white p-6 rounded-[2.5rem] border-2 transition-all duration-500 shadow-xl ${isDelivered ? 'opacity-50 grayscale border-gray-100 shadow-none' : 'border-emerald-50 hover:border-emerald-300 shadow-emerald-100/30'}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <span className={`text-[9px] px-3 py-1 rounded-full font-black uppercase tracking-widest border ${isDelivered ? 'bg-gray-100 text-gray-400 border-gray-200' : 'bg-amber-100 text-amber-700 border-amber-200'}`}>
                        {isDelivered ? 'ডেলিভারি সম্পন্ন' : order.order_no}
                      </span>
                      <h3 className="font-black text-xl text-emerald-900 mt-3 leading-none">{phar?.name || 'অজ্ঞাত'}</h3>
                      <p className="text-[10px] font-bold text-gray-400 mt-2 uppercase tracking-tighter flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-200"></span> তারিখ: {order.order_date}
                      </p>
                    </div>
                    {!isDelivered && (
                      <div className="flex gap-2">
                        <button onClick={() => deliverOrder(order)} className="bg-emerald-700 text-white px-5 py-3 rounded-2xl text-[11px] font-black shadow-lg shadow-emerald-100 active:scale-90 transition-all uppercase tracking-tighter">ডেলিভারি</button>
                        <button onClick={() => handleDelete(order.id)} className="bg-rose-50 text-rose-300 p-3 rounded-2xl active:scale-75 transition-all">🗑️</button>
                      </div>
                    )}
                  </div>
                  <div className="mt-6 pt-5 border-t-2 border-emerald-50/50 flex justify-between items-end">
                    <div className="flex flex-col">
                      <span className="text-[9px] font-black text-gray-300 uppercase leading-none mb-1">আইটেম সংখ্যা</span>
                      <span className="font-black text-emerald-800 text-sm">{state.orderItems.filter(oi => oi.order_id === order.id).length} পিস মাল</span>
                    </div>
                    <div className="flex flex-col text-right">
                      <span className="text-[9px] font-black text-gray-300 uppercase leading-none mb-1">মোট বিল</span>
                      <span className="font-black text-emerald-900 text-2xl">৳{order.total_amount}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};

export default OrderPage;
