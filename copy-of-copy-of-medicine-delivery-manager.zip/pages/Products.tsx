
import React, { useState } from 'react';
import { AppState, Product } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const ProductsPage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Partial<Product> | null>(null);

  const filteredProducts = state.products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.product_no.toLowerCase().includes(search.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.name || !editing?.price) return;

    if (editing.id) {
      setState(prev => ({
        ...prev,
        products: prev.products.map(p => p.id === editing.id ? (editing as Product) : p)
      }));
    } else {
      const newProduct: Product = {
        id: generateId(),
        product_no: editing.product_no || `P${Math.floor(Math.random() * 10000)}`,
        name: editing.name,
        price: Number(editing.price)
      };
      setState(prev => ({
        ...prev,
        products: [...prev.products, newProduct]
      }));
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('এই প্রোডাক্টটি চিরতরে ডিলিট করতে চান?')) {
      requireAdmin(() => {
        setState(prev => ({
          ...prev,
          products: prev.products.filter(p => p.id !== id),
          stock: prev.stock.filter(s => s.product_id !== id)
        }));
      });
    }
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">প্রোডাক্ট লিস্ট</h2>
        <button 
          onClick={() => setEditing({})}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md active:scale-95 transition-all"
        >
          নতুন প্রোডাক্ট +
        </button>
      </div>

      <div className="sticky top-20 z-10">
        <div className="relative">
          <input 
            type="text"
            placeholder="নাম বা নং দিয়ে খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full border-2 border-emerald-500 rounded-2xl p-4 pl-12 shadow-md focus:ring-4 focus:ring-emerald-200 bg-emerald-100 text-emerald-900 font-bold placeholder-emerald-700 transition-all outline-none"
          />
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl grayscale opacity-70">🔍</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredProducts.map(p => (
          <div key={p.id} className="bg-white p-4 rounded-2xl border border-gray-100 flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center font-black">
                {p.name[0].toUpperCase()}
              </div>
              <div>
                <h3 className="font-bold text-gray-800">{p.name}</h3>
                <p className="text-emerald-500 font-bold text-xs uppercase">নং: {p.product_no}</p>
                <p className="text-green-600 font-black text-sm">৳{p.price}</p>
              </div>
            </div>
            <div className="flex gap-1">
              <button onClick={() => setEditing(p)} className="p-2 text-emerald-500 hover:bg-emerald-50 rounded-lg transition-colors">✏️</button>
              <button onClick={() => handleDelete(p.id)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">🗑️</button>
            </div>
          </div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-20 opacity-30 grayscale">
          <span className="text-6xl mb-4 block">💊</span>
          <p className="font-bold">কোনো প্রোডাক্ট পাওয়া যায়নি</p>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl w-full max-w-sm shadow-2xl animate-in">
            <h2 className="text-2xl font-black mb-6 text-emerald-800">{editing.id ? 'প্রোডাক্ট এডিট' : 'নতুন প্রোডাক্ট যোগ'}</h2>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-emerald-700 uppercase mb-1 ml-1">প্রোডাক্টের নাম</label>
                <input 
                  autoFocus
                  required
                  type="text" 
                  value={editing.name || ''} 
                  onChange={e => setEditing({...editing, name: e.target.value})}
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-xl p-3 focus:ring-4 focus:ring-emerald-200 outline-none text-emerald-900 font-bold"
                  placeholder="যেমন: Napa Extend"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-black text-emerald-700 uppercase mb-1 ml-1">প্রোডাক্ট নং (ঐচ্ছিক)</label>
                <input 
                  type="text" 
                  value={editing.product_no || ''} 
                  onChange={e => setEditing({...editing, product_no: e.target.value})}
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-xl p-3 focus:ring-4 focus:ring-emerald-200 outline-none text-emerald-900 font-bold"
                  placeholder="যেমন: P-102"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-black text-emerald-700 uppercase mb-1 ml-1">বিক্রয় মূল্য (৳)</label>
                <input 
                  required
                  type="number" 
                  value={editing.price || ''} 
                  onChange={e => setEditing({...editing, price: Number(e.target.value)})}
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-xl p-3 focus:ring-4 focus:ring-emerald-200 outline-none text-emerald-900 font-bold"
                  placeholder="0.00"
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setEditing(null)} className="flex-1 text-gray-400 font-bold py-3">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-3 rounded-2xl font-bold shadow-lg active:scale-95 transition-all">সেভ করুন</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ProductsPage;
