
import React, { useState } from 'react';
import { AppState, Stock } from '../types';

interface Props {
  state: AppState;
  setState: (updater: (prev: AppState) => AppState) => void;
  requireAdmin: (action: () => void) => void;
}

const StockPage: React.FC<Props> = ({ state, setState, requireAdmin }) => {
  const [editing, setEditing] = useState<Partial<Stock> | null>(null);

  const getProductName = (id: string) => state.products.find(p => p.id === id)?.name || 'অজ্ঞাত প্রোডাক্ট';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.product_id || editing.quantity === undefined) return;

    if (editing.id) {
      setState(prev => ({
        ...prev,
        stock: prev.stock.map(s => s.id === editing.id ? (editing as Stock) : s)
      }));
    } else {
      const newStock: Stock = {
        id: crypto.randomUUID(),
        product_id: editing.product_id,
        quantity: Number(editing.quantity),
        purchase_price: Number(editing.purchase_price || 0),
        arrival_date: editing.arrival_date || new Date().toISOString().split('T')[0],
        min_limit: Number(editing.min_limit || 5)
      };
      setState(prev => ({
        ...prev,
        stock: [...prev.stock, newStock]
      }));
    }
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('স্টক রেকর্ড ডিলিট করতে চান?')) {
      requireAdmin(() => {
        setState(prev => ({
          ...prev,
          stock: prev.stock.filter(s => s.id !== id)
        }));
      });
    }
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">স্টক ম্যানেজমেন্ট</h2>
        <button 
          onClick={() => setEditing({ arrival_date: new Date().toISOString().split('T')[0], min_limit: 5 })}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md active:scale-95 transition-all"
        >
          স্টক যোগ +
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {state.stock.length === 0 ? (
          <div className="text-center py-20 opacity-20 grayscale">
            <span className="text-6xl block">📦</span>
            <p className="font-bold mt-4">কোনো স্টক ডাটা নেই</p>
          </div>
        ) : (
          state.stock.map(s => {
            const isLow = s.quantity <= (s.min_limit || 5);
            return (
              <div key={s.id} className={`bg-white p-5 rounded-2xl border transition-all shadow-sm flex justify-between items-center ${isLow ? 'border-rose-200 bg-rose-50/30' : 'border-gray-50'}`}>
                <div className="flex-1">
                  <h3 className="font-bold text-emerald-900 text-lg flex items-center">
                    {getProductName(s.product_id)}
                    {isLow && <span className="ml-2 bg-rose-500 text-white text-[8px] px-1.5 py-0.5 rounded-full uppercase">Low</span>}
                  </h3>
                  <div className="mt-1">
                    <span className="text-[10px] text-gray-400 uppercase font-bold mr-2">বর্তমান মজুদ:</span>
                    <span className={`text-2xl font-black ${isLow ? 'text-rose-600' : 'text-emerald-600'}`}>{s.quantity} পিস</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditing(s)} className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center border border-emerald-100">✏️</button>
                  <button onClick={() => handleDelete(s.id)} className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center border border-rose-100">🗑️</button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl w-full max-w-sm shadow-2xl animate-in">
            <h2 className="text-2xl font-black mb-6 text-emerald-800">স্টক এন্ট্রি</h2>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-emerald-700 uppercase">প্রোডাক্ট নাম</label>
                <select 
                  required
                  value={editing.product_id || ''} 
                  onChange={e => setEditing({...editing, product_id: e.target.value})}
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-xl p-3 focus:ring-4 focus:ring-emerald-200 outline-none text-emerald-900 font-bold"
                >
                  <option value="">প্রোডাক্ট সিলেক্ট করুন...</option>
                  {state.products.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-emerald-700 uppercase">পরিমাণ (Quantity)</label>
                <input 
                  required 
                  type="number" 
                  value={editing.quantity || ''} 
                  onChange={e => setEditing({...editing, quantity: Number(e.target.value)})} 
                  className="w-full bg-emerald-100 border-2 border-emerald-500 rounded-xl p-3 focus:ring-4 focus:ring-emerald-200 outline-none text-emerald-900 font-bold" 
                  placeholder="কত পিস?"
                />
              </div>
              
              {/* Optional Advanced Fields - hidden or simplified based on prompt but kept for DB integrity */}
              <div className="grid grid-cols-2 gap-3 opacity-60">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-emerald-700 uppercase">ক্রয় মূল্য</label>
                  <input type="number" value={editing.purchase_price || ''} onChange={e => setEditing({...editing, purchase_price: Number(e.target.value)})} className="w-full bg-emerald-50 border-2 border-emerald-200 rounded-xl p-2 text-sm outline-none font-bold" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-emerald-700 uppercase">লিমিট</label>
                  <input type="number" value={editing.min_limit || 5} onChange={e => setEditing({...editing, min_limit: Number(e.target.value)})} className="w-full bg-emerald-50 border-2 border-emerald-200 rounded-xl p-2 text-sm outline-none font-bold" />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setEditing(null)} className="flex-1 text-gray-400 font-bold py-3">বাতিল</button>
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-3 rounded-2xl font-bold shadow-lg active:scale-95">সেভ করুন</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default StockPage;
