
import React from 'react';
import { db } from '../dbService';
import { AppState } from '../types';

interface Props {
  state: AppState;
  setState: (state: AppState) => void;
}

const BackupPage: React.FC<Props> = ({ state, setState }) => {
  const handleExport = () => {
    const data = db.backup();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medicine_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (db.restore(content)) {
        setState(db.get());
        alert('ডেটা সফলভাবে রিস্টোর করা হয়েছে!');
      } else {
        alert('রিস্টোর ব্যর্থ হয়েছে। ফাইলটি সঠিক কিনা যাচাই করুন।');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-emerald-900">ব্যাকআপ ও নিরাপত্তা</h2>
      
      {/* Cloud Auto Backup Info */}
      <div className="bg-emerald-600 text-white p-6 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">☁️</span>
            <h3 className="font-black text-lg uppercase">অটো ক্লাউড ব্যাকআপ চালু</h3>
          </div>
          <p className="text-xs font-bold opacity-90 mb-4">আপনার সমস্ত ডাটা সুরক্ষিতভাবে এই ইমেইলে সেভ হচ্ছে:</p>
          <div className="bg-emerald-800/50 p-3 rounded-2xl border border-emerald-400 inline-block">
            <p className="font-mono font-black text-sm select-all">Sisirshohag043@gmail.com</p>
          </div>
          <p className="text-[10px] mt-4 font-bold uppercase opacity-70 tracking-tighter italic">* গুগলের সুরক্ষিত ডাটাবেস (Firestore) ব্যবহার করা হচ্ছে</p>
        </div>
        {/* Decorative cloud icon background */}
        <span className="absolute -right-8 -bottom-8 text-[120px] opacity-10 rotate-12">☁️</span>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border-2 border-emerald-50 text-center space-y-6">
        <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-100">
          <span className="text-3xl">💾</span>
        </div>
        
        <div>
          <h3 className="text-xl font-bold text-gray-800">অফলাইন ব্যাকআপ</h3>
          <p className="text-gray-400 text-xs mt-1 font-bold uppercase">নিরাপত্তার জন্য একটি ফাইল ডাউনলোড করে রাখুন</p>
          <button 
            onClick={handleExport}
            className="mt-4 w-full bg-emerald-50 text-emerald-700 border-2 border-emerald-500 py-4 rounded-2xl font-black text-lg shadow-md active:scale-95 transition-all"
          >
            ব্যাকআপ ফাইল নামান (JSON)
          </button>
        </div>

        <div className="pt-6 border-t-2 border-emerald-50">
          <h3 className="text-xl font-black text-emerald-800">ডেটা রিস্টোর</h3>
          <p className="text-gray-400 text-xs mt-1 font-bold uppercase">পুরানো ফাইল থেকে ডেটা ফিরে আনুন</p>
          <div className="mt-4 relative">
            <input 
              type="file" 
              accept=".json"
              onChange={handleImport}
              className="hidden" 
              id="restore-file" 
            />
            <label 
              htmlFor="restore-file"
              className="block w-full border-2 border-dashed border-emerald-300 bg-emerald-50/30 py-4 rounded-2xl cursor-pointer hover:bg-emerald-100 hover:border-emerald-500 transition-all font-black text-emerald-600"
            >
              ফাইল সিলেক্ট করুন 📂
            </label>
          </div>
        </div>
      </div>

      <div className="bg-rose-50 p-5 rounded-3xl border-2 border-rose-100 flex items-start gap-4">
        <span className="text-2xl mt-1">⚠️</span>
        <p className="text-xs text-rose-800 font-bold leading-relaxed uppercase tracking-tight">
          সাবধান: রিস্টোর করলে বর্তমান সমস্ত ডেটা মুছে গিয়ে ব্যাকআপ ফাইলের ডেটা দিয়ে রিপ্লেস হবে। এটি অ্যাডমিন ছাড়া করবেন না।
        </p>
      </div>
    </div>
  );
};

export default BackupPage;
