
import React, { useState, useEffect } from 'react';
import { db } from './dbService';
import { AppState } from './types';
import Dashboard from './pages/Dashboard';
import ProductsPage from './pages/Products';
import StockPage from './pages/Stock';
import PharmacyPage from './pages/Pharmacies';
import InvoicePage from './pages/Invoices';
import OrderPage from './pages/Orders';
import LedgerPage from './pages/Ledger';
import ReportsPage from './pages/Reports';
import BackupPage from './pages/Backup';
import LoginPage from './pages/Login';
import AdminModal from './components/AdminModal';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(db.get());
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [onAdminSuccess, setOnAdminSuccess] = useState<(() => void) | null>(null);

  useEffect(() => {
    setIsSyncing(true);
    db.save(state);
    const timer = setTimeout(() => setIsSyncing(false), 1200);
    return () => clearTimeout(timer);
  }, [state]);

  const updateState = (updater: (prev: AppState) => AppState) => {
    setState(prev => updater(prev));
  };

  const requireAdmin = (action: () => void) => {
    if (isAdmin) {
      action();
    } else {
      setOnAdminSuccess(() => action);
      setAdminModalOpen(true);
    }
  };

  if (!isLoggedIn) {
    return <LoginPage onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  const renderContent = () => {
    return (
      <div key={activeTab} className="page-transition min-h-full">
        {(() => {
          switch (activeTab) {
            case 'dashboard': return <Dashboard state={state} setActiveTab={setActiveTab} />;
            case 'products': return <ProductsPage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'stock': return <StockPage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'pharmacies': return <PharmacyPage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'orders': return <OrderPage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'invoices': return <InvoicePage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'ledger': return <LedgerPage state={state} setState={updateState} requireAdmin={requireAdmin} />;
            case 'reports': return <ReportsPage state={state} />;
            case 'backup': return <BackupPage state={state} setState={setState} />;
            default: return <Dashboard state={state} setActiveTab={setActiveTab} />;
          }
        })()}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#f1f5f9]">
      <header className="flex-none app-gradient text-white safe-area-top shadow-[0_8px_30px_rgba(4,120,87,0.3)] z-50">
        <div className="flex justify-between items-center px-6 py-5">
          <div className="flex flex-col">
            <h1 className="text-2xl font-black tracking-tighter leading-none uppercase italic drop-shadow-lg">শিশির</h1>
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-amber-400 animate-pulse' : 'bg-emerald-300'}`}></span>
              <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-80">Sync Online</span>
            </div>
          </div>
          <button onClick={() => setIsLoggedIn(false)} className="text-[10px] font-black bg-white/10 hover:bg-white/20 px-4 py-2.5 rounded-2xl border border-white/20 uppercase backdrop-blur-md transition-all active:scale-90">Logout</button>
        </div>
      </header>

      <main className="flex-grow overflow-y-auto scrollbar-hide px-4 pt-6 pb-36">
        <div className="max-w-md mx-auto h-full">
          {renderContent()}
        </div>
      </main>

      {/* Colorful & Beautiful Navigation Bar */}
      <nav className="fixed bottom-4 left-3 right-3 bg-white/95 backdrop-blur-3xl rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-white/50 z-50 safe-area-bottom">
        <div className="flex items-center h-20 px-4 overflow-x-auto scrollbar-hide no-scrollbar snap-x snap-mandatory">
          <NavItem 
            icon="🏠" 
            label="হোম" 
            active={activeTab === 'dashboard'} 
            color="text-emerald-500" 
            bgColor="bg-emerald-500"
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon="📦" 
            label="মাল" 
            active={activeTab === 'products'} 
            color="text-sky-500" 
            bgColor="bg-sky-500"
            onClick={() => setActiveTab('products')} 
          />
          <NavItem 
            icon="📊" 
            label="স্টক" 
            active={activeTab === 'stock'} 
            color="text-amber-500" 
            bgColor="bg-amber-500"
            onClick={() => setActiveTab('stock')} 
          />
          <NavItem 
            icon="🏥" 
            label="দোকান" 
            active={activeTab === 'pharmacies'} 
            color="text-teal-500" 
            bgColor="bg-teal-500"
            onClick={() => setActiveTab('pharmacies')} 
          />
          <NavItem 
            icon="🛒" 
            label="অর্ডার" 
            active={activeTab === 'orders'} 
            color="text-indigo-500" 
            bgColor="bg-indigo-500"
            onClick={() => setActiveTab('orders')} 
          />
          <NavItem 
            icon="📝" 
            label="বিল" 
            active={activeTab === 'invoices'} 
            color="text-rose-500" 
            bgColor="bg-rose-500"
            onClick={() => setActiveTab('invoices')} 
          />
          <NavItem 
            icon="📖" 
            label="বাকি" 
            active={activeTab === 'ledger'} 
            color="text-orange-500" 
            bgColor="bg-orange-500"
            onClick={() => setActiveTab('ledger')} 
          />
          <NavItem 
            icon="📈" 
            label="রিপোর্ট" 
            active={activeTab === 'reports'} 
            color="text-violet-500" 
            bgColor="bg-violet-500"
            onClick={() => setActiveTab('reports')} 
          />
          <NavItem 
            icon="⚙️" 
            label="সেটিং" 
            active={activeTab === 'backup'} 
            color="text-gray-500" 
            bgColor="bg-gray-500"
            onClick={() => setActiveTab('backup')} 
          />
        </div>
      </nav>

      {adminModalOpen && (
        <AdminModal
          onClose={() => { setAdminModalOpen(false); setOnAdminSuccess(null); }}
          onSuccess={() => { setIsAdmin(true); setAdminModalOpen(false); if (onAdminSuccess) onAdminSuccess(); setOnAdminSuccess(null); }}
        />
      )}
    </div>
  );
};

const NavItem = ({ icon, label, active, color, bgColor, onClick }: { icon: string, label: string, active: boolean, color: string, bgColor: string, onClick: () => void }) => (
  <button 
    onClick={onClick} 
    className={`flex flex-col items-center justify-center min-w-[72px] h-full transition-all duration-300 relative snap-center ${active ? color : 'text-gray-300'}`}
  >
    {active && (
      <>
        <div className={`absolute -top-1 w-8 h-1 ${bgColor} rounded-full blur-[2px]`}></div>
        <div className={`absolute top-0 w-2 h-2 ${bgColor} rounded-full animate-ping opacity-20`}></div>
      </>
    )}
    <div className={`text-2xl transition-all duration-300 mb-1 ${active ? 'scale-125 -translate-y-1.5 drop-shadow-[0_4px_10px_rgba(0,0,0,0.1)]' : 'opacity-40 grayscale blur-[0.3px]'}`}>
      {icon}
    </div>
    <span className={`text-[9px] font-black uppercase tracking-tighter transition-all ${active ? 'opacity-100 scale-105' : 'opacity-40 scale-90'}`}>
      {label}
    </span>
  </button>
);

export default App;
