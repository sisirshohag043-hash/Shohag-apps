
export interface Product {
  id: string;
  product_no: string;
  name: string;
  price: number;
}

export interface Stock {
  id: string;
  product_id: string;
  quantity: number;
  purchase_price: number;
  arrival_date: string;
  min_limit: number;
}

export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  mobile: string;
  owner_name?: string;
}

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
}

export interface Payment {
  id: string;
  invoice_id: string;
  pharmacy_id: string;
  amount: number;
  date: string;
  type: 'Sale' | 'Due_Collection';
}

export interface Invoice {
  id: string;
  invoice_no: string;
  pharmacy_id: string;
  delivery_date: string;
  total_amount: number;
  cash_received: number;
  due_amount: number;
  status: 'Paid' | 'Partial' | 'Due';
}

export interface Order {
  id: string;
  order_no: string;
  pharmacy_id: string;
  order_date: string;
  delivery_date: string;
  total_amount: number;
  status: 'Pending' | 'Delivered' | 'Cancelled';
}

export interface AppState {
  products: Product[];
  stock: Stock[];
  pharmacies: Pharmacy[];
  invoices: Invoice[];
  invoiceItems: InvoiceItem[];
  payments: Payment[];
  orders: Order[];
  orderItems: OrderItem[];
}
