
import React, { useState } from 'react';

interface Props {
  onClose: () => void;
  onSuccess: () => void;
}

const AdminModal: React.FC<Props> = ({ onClose, onSuccess }) => {
  const [adminId, setAdminId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminId === '01818813357' && password === '01818813357') {
      onSuccess();
    } else {
      setError('ভুল আইডি অথবা পাসওয়ার্ড');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
      <div className="bg-white rounded-3xl p-8 w-full max-w-sm shadow-2xl animate-in">
        <h2 className="text-3xl font-black mb-2 text-center text-emerald-600">ভেরিফিকেশন</h2>
        <p className="text-gray-400 mb-8 text-center text-[10px] font-black uppercase tracking-[0.2em] leading-relaxed">নিরাপত্তার জন্য লগইন করুন</p>
        
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black text-emerald-700 uppercase mb-2 ml-1">অ্যাডমিন আইডি</label>
            <input
              type="text"
              value={adminId}
              onChange={(e) => setAdminId(e.target.value)}
              className="w-full border-2 border-emerald-500 rounded-2xl p-4 bg-emerald-100 text-emerald-900 font-black focus:ring-4 focus:ring-emerald-200 outline-none transition-all placeholder-emerald-400"
              placeholder="আইডি লিখুন"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-emerald-700 uppercase mb-2 ml-1">গোপন পাসওয়ার্ড</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border-2 border-emerald-500 rounded-2xl p-4 bg-emerald-100 text-emerald-900 font-black focus:ring-4 focus:ring-emerald-200 outline-none transition-all placeholder-emerald-400"
              placeholder="••••••••"
              required
            />
          </div>
          {error && <div className="bg-rose-50 text-rose-600 p-3 rounded-xl text-xs text-center font-black border-2 border-rose-100 animate-pulse">{error}</div>}
          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 font-bold text-gray-400 py-4"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="flex-1 bg-emerald-600 text-white p-4 rounded-2xl font-black text-lg shadow-xl active:scale-95 transition-all"
            >
              লগইন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminModal;
